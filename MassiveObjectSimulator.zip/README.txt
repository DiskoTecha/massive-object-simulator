Massive Object Simulator
Copyright 2023 Dylan Wadsworth
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
CONTROLS:
w,a,s,d - Move Camera
mouse movement - Rotate Camera
esc - Exit Program